<html>
<head><title>Create database BOOKTRADE</title></head>
<body>
  <tr> 
  <td colspan="2" height="67"> 
  <h2>BOOKTRADE database</h2>
  </td>
  </tr>
  <body>
  
  
  
  <p>
  
  <?php
  
  
  $con = mysql_connect("localhost","bdms","bdms");
  
  
  if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
  
  if (mysql_query("DROP DATABASE booktrade_tutorial ; ",$con))
  {
  echo "<p>Database deleted! </p>";
  }
  else
  {
  echo "Error deleting database: " . mysql_error();
  }
  
  if (mysql_query("CREATE DATABASE booktrade_tutorial ; ",$con))
  {
  echo "<p>Database created!</p> ";
  }
  else
  {
  echo "Error creating database: " . mysql_error();
  }
  
  mysql_close($con);
  
  $query = "
  CREATE TABLE BOOK
  ( 
  B_ID INT NOT NULL AUTO_INCREMENT,
  TITLE VARCHAR(150) NOT NULL,
  AUTHOR INT(4),
  LANGUAGE CHAR(3),
  PUBLISHER INT(4),
  EXTENT VARCHAR(10),
  YEAR INT(4),
  ORIGINAL INT(4),
  TRANSLATOR INT(4),
  PRIMARY KEY (B_ID),
  FOREIGN KEY (AUTHOR) REFERENCES PERSON ON DELETE RESTRICT ON UPDATE CASCADE,
  FOREIGN KEY (LANGUAGE) REFERENCES LANGUAGE ON DELETE RESTRICT ON UPDATE CASCADE,
  FOREIGN KEY (PUBLISHER) REFERENCES COMPANY ON DELETE RESTRICT ON UPDATE CASCADE,
  FOREIGN KEY (ORIGINAL) REFERENCES BOOK ON DELETE RESTRICT ON UPDATE CASCADE,
  FOREIGN KEY (TRANSLATOR) REFERENCES PERSON ON DELETE RESTRICT ON UPDATE CASCADE
  ) ; 
  " ; 
  
  executeSQL( $query ) ; 
  
  $query = "
  CREATE TABLE FILM
  ( 
  F_ID INT NOT NULL AUTO_INCREMENT,
  TITLE VARCHAR(150) NOT NULL,
  BASED_ON INT(4),
  LANGUAGE CHAR(3),
  DIRECTOR INT(4),
  YEAR INT(4),
  COMMENTS INT(100),
  PRIMARY KEY (F_ID),
  FOREIGN KEY (BASED_ON) REFERENCES BOOK ON DELETE RESTRICT ON UPDATE CASCADE,
  FOREIGN KEY (LANGUAGE) REFERENCES LANGUAGE ON DELETE RESTRICT ON UPDATE CASCADE,
  FOREIGN KEY (DIRECTOR) REFERENCES PERSON ON DELETE RESTRICT ON UPDATE CASCADE
  ) ; 
  " ; 
  
  executeSQL( $query ) ; 
  
  
  $query = "
  CREATE TABLE CITY
  ( 
  CITY_CODE CHAR(6) NOT NULL,
  CITY_NAME VARCHAR(60) NOT NULL,
  COUNTRY CHAR(3),
  PRIMARY KEY (CITY_CODE),
  FOREIGN KEY (COUNTRY) REFERENCES COUNTRY ON DELETE RESTRICT ON UPDATE CASCADE
  ) ;
  " ; 
  
  executeSQL( $query ) ; 
  
  
  $query = "
  CREATE TABLE LANGUAGE
  ( 
  LANG_CODE CHAR(3) NOT NULL,
  LANG_NAME VARCHAR(60) NOT NULL,
  PRIMARY KEY (LANG_CODE)
  ) ; 
  " ; 
  
  executeSQL( $query ) ; 
  
  
  $query = "
  CREATE TABLE SERIES
  ( 
  S_ID INT NOT NULL AUTO_INCREMENT,
  TITLE VARCHAR(150) NOT NULL,
  YEAR_START INT(4),
  YEAR_END INT(4),
  PRIMARY KEY ( S_ID )
  ) ; 
  " ; 
  
  executeSQL( $query ) ; 
  
  
  $query = "
  CREATE TABLE PERSON
  ( 
  P_ID INT(4) NOT NULL AUTO_INCREMENT,
  NAME_LAST VARCHAR(100) NOT NULL,
  NAME_FIRST VARCHAR(150) NOT NULL,
  YEAR_OF_BIRTH INT (4),
  YEAR_OF_DEATH INT (4),
  COUNTRY_BORN CHAR(3),
  PRIMARY KEY (P_ID),
  FOREIGN KEY (COUNTRY_BORN) REFERENCES COUNTRY ON DELETE RESTRICT ON UPDATE CASCADE
  ) ; 
  " ; 
  
  executeSQL( $query ) ; 
  
  
  
  $query = "
  CREATE TABLE EMPLOYMENT
  ( 
  E_ID INT(4) NOT NULL AUTO_INCREMENT,
  EMPLOYEE INT(4),
  EMPLOYER INT(4),
  FUNCTION VARCHAR(60),
  YEAR_START INT(4),
  YEAR_END INT(4),
  PRIMARY KEY (E_ID),
  FOREIGN KEY (EMPLOYEE) REFERENCES PERSON ON DELETE RESTRICT ON UPDATE CASCADE,
  FOREIGN KEY (EMPLOYER) REFERENCES COMPANY ON DELETE RESTRICT ON UPDATE CASCADE
  ) ;
  " ; 
  
  executeSQL( $query ) ; 
  
  $query = "
  CREATE TABLE COUNTRY
  ( 
  COUNTRY_CODE CHAR(3) NOT NULL,
  COUNTRY_NAME VARCHAR(100),
  PRIMARY KEY (COUNTRY_CODE)
  ) ; 
  " ; 
  
  executeSQL( $query ) ; 
  


  
  $query = "
  CREATE TABLE SERIALISATION
  ( 
  SER_ID INT(4) NOT NULL AUTO_INCREMENT,
  SERIES INT(4),
  BOOK INT(4),
  NUMBER CHAR(50),
  PRIMARY KEY (SER_ID),
  FOREIGN KEY (SERIES) REFERENCES SERIES ON DELETE RESTRICT ON UPDATE CASCADE,
  FOREIGN KEY (BOOK) REFERENCES BOOK ON DELETE RESTRICT ON UPDATE CASCADE
  ) ; 
  " ; 
  
  executeSQL( $query ) ; 
  
  
  $query = "
  CREATE TABLE COMPANY
  ( 
  C_ID INT(4) NOT NULL AUTO_INCREMENT,
  NAME VARCHAR(100),
  ADDRESS VARCHAR(150),
  CITY CHAR(6),
  TELEPHONE VARCHAR(20),
  PRIMARY KEY (C_ID),
  FOREIGN KEY (CITY) REFERENCES CITY ON DELETE RESTRICT ON UPDATE CASCADE
  ) ; 
  " ; 
  
  executeSQL( $query ) ; 
  
  $query = "
  INSERT INTO BOOK VALUES 
  ('5','Eline Vere : Een Haagsche roman','5','dut','4','448','1979', NULL, NULL), 
  ('6','Stille kracht, de','5','dut','11','246','1900', NULL, NULL), 
  ('7','My San Francisco','4','eng','5','23','1932', NULL, NULL), 
  ('8','Certain People of Importance','4','eng','5','486','1922' , NULL, NULL), 
  ('9','Lost sunrise','4','eng','5','349','1939' , NULL, NULL), 
  ('10','Miss Pinkerton','3','eng','6','224','1946', NULL, NULL), 
  ('11','Circular staircase, The','3','eng','10','178','1997', NULL, NULL), 
  ('12','One Wonderful Night','8','eng','8','320','1913' , NULL, NULL), 
  ('13','Silent Barrier, The','8','eng','9','349','1920' , NULL, NULL), 
  ('14','Mysterious Affair at Styles, The','15','eng','10','153','1967' , NULL, NULL), 
  ('15','Getting George Married','6','eng','7','286','1933' , NULL, NULL), 
  ('16','Dark House, The','20','eng','15','407','1941' , NULL, NULL), 
  ('17','Kitty Carstairs','19','eng','16','280','1918' , NULL, NULL), 
  ('18','Fault of one, the','21','eng','3','258','1897' , NULL, NULL), 
  ('19','George wordt belegerd','6','dut','17','222','1934','15','28'), 
  ('20','Eline Vere, translated from the Dutch','5','eng','13','312','1892','5','12'), 
  ('21','Fuerza oculta','5','spa','15','248','1922','6','13'), 
  ('22','Hidden force, the','5','eng','15','254','1992','6','12'), 
  ('23','Donkere huis, het','20','dut','17','405','1954','16','28'), 
  ('24','Onberaden stap, een','21','dut','17','224','1932','18','30') ;
  " ; 
  
  executeSQL( $query ) ; 
  
  
  $query = "
  INSERT INTO CITY VALUES ('GB EGB','East Grinstead','uk'), ('GB LON','London','uk'), ('GB OXF','Oxford','uk'), ('NL AMS','Amsterdam','nl'), ('NL HAA','Haarlem','nl'), ('NL HAG','The Hague','nl'), ('NL LID','Leiden','nl'), ('NL NIJ','Nijmegen','nl'), ('US NYC','New York','us'), ('US PHL','Philadelphia','us') ; 
  " ; 
  
  executeSQL( $query ) ; 
  
  
  

  
  
  
  $query = "
  INSERT INTO COMPANY VALUES 
  ('2','Oxford University Press','Great Clarendon Street','GB OXF','+44 (0) 1865 556767'),
  ('3','Lippincott, J. B.','700 Block Market St','US PHL','(215) 744-2145'), 
  ('4','Kampen, P.N. Van.','','NL AMS','+32 020-5265779'), 
  ('5','Doubleday, Doran & Co.','','US NYC', ''), 
  ('6','Bantam Dell Publishing Group','','US NYC', ''), 
  ('7','Long, John','','GB LON', ''), 
  ('8','Ward, Lock and Company','1 Christopher Road','GB EGB','+44 (0) 1342 318980'), 
  ('9','Grosset & Dunlap','','US NYC', ''), 
  ('10','Dover Publications','','US NYC', ''), 
  ('11','Veen, L.J.','Herengracht 481','NL AMS','+31 (020) 5249800'), 
  ('12','Quartet Books Publishers','27 Goodge Street','GB LON','+44 (020) 7636 3992'), 
  ('13','Luithingh-Sijthoff','Leidsegracht 105A','NL AMS','+31 (020) 5307340' ), 
  ('14','Penguin Books','27 Wrights Lane','GB LON','+44 (020) 7652 1659' ), 
  ('15','Cassell & Co.','','GB LON', ''), 
  ('16','Stokes','','US NYC', ''), 
  ('17','Hollandsche Bibliotheek','','NL HAA', ''), 
  ('18','English Bookbinders','Dam','NL AMS', ''), 
  ('19','Frederik M�ller Antiquariaat','','NL AMS', ''), 
  ('20','Sijthoff, A.W.','Doezastraat 1, 3 & 5','NL LID' , ''), 
  ('21','Fuhri, Koenraad','Papestraat','NL HAA' , ''), 
  ('22','Thieme, J.F. en Zonen','','NL NIJ' , ''), 
  ('23','Mandemaker, W.K.','Papestraat','NL HAA', '') ;
  " ; 
  
  executeSQL( $query ) ; 
  
  
  $query = "
  INSERT INTO COUNTRY VALUES ('be','Belgium'), ('ca','Canada'), ('de','Germany'), ('fr','France'), ('ie','Ireland'), ('mx','Mexico'), ('nl','Netherlands'), ('uk','Great Britain'), ('us','United States') ;   
  " ; 
  executeSQL( $query ) ; 
  
  $query = "
  INSERT INTO FILM VALUES 
  ('1', 'One Wonderful Night', '12', 'eng', '7', '1914' , '')	,
  ('2', 'One Wonderful Night', '12', 'eng', '9', '1944' , '')	,
  ('3', 'Silent Barrier, The', '13', 'eng', '11', '1920' , ''),
  ('4', 'Circular Staircase, The', '11', 'eng', '', '1925' , ''),	
  ('5', 'Beyond London Lights', '17', 'eng', '', '1928' , ''),	
  ('7', 'Certain People of Importance', '8', 'eng', '10', '1924' , ''),
  ('9', 'Stille Kracht', '6', 'dut', '27', '1974' , ''); " ;
  executeSQL( $query ) ; 
  
  
  $query = "
  INSERT INTO SERIALISATION VALUES 
  ('1', '1', '11', '1' ),
  ('2', '1', '14', '2' ),
  ('4', '4', '16', '17' ),
  ('5', '4', '17', '23' ),
  ('6', '4', '14', '15' ),
  ('10', '1', '13', '4' ); ";
  executeSQL( $query ) ; 
  
  
  $query = "
  INSERT INTO SERIES VALUES 
  ('1', 'Dover mystery classics', '1975', '1998' ),
  ('4', 'Hollandsche Bibliotheek', '', '' ); 	
  " ; 
  executeSQL( $query ) ; 
  
  $query = "
  INSERT INTO LANGUAGE VALUES ('dut','Dutch'), ('eng','English'), ('fre','French'), ('ger','German'), ('spa','Spanish') ; 
  " ; 
  
  executeSQL( $query ) ; 
  
  $query = "
  INSERT INTO EMPLOYMENT VALUES ('1','23','19','Publishers','1846','1867'), ('2','22','18','Bookbinder','1826','1858'), ('3','24','20','Publisher','1851','1891'), ('4','25','20','Publisher','1878','1909'), ('5','26','21','Bookseller','1837','1855'), ('6','24','21','Bookseller','1848','1850'), ('7','26','22','Apprentice','1830','1834'), ('8','26','23','Bookseller','1834','1837') ; 
  " ; 
  
  executeSQL( $query ) ; 
  
  
  $query = "
  INSERT INTO PERSON VALUES ('1','Austen','Jane','1775','1817','uk'), ('2','Goldsmith','Oliver','1730','1774','ie'), ('3','Rinehart','Mary Roberts','1876','1958','us'), ('4','Norris','Kathleen','1880','1960','us'), ('5','Couperus','Louis','1863','1923','nl'), ('6','Kilpatrick','Florence Antoinette','1891','1968','us'), ('7','Calvert','Elisha','1863','1941','us'), ('8','Tracy','Louis','1862','1928','us'), ('9','Paton','Stuart','1883','1944','uk'), ('10','Worthington','William','1872','1942','us'), ('11','K�mel','Harry','1940','','be'), ('12','Grein','James Thomas','1862','1935','us'), ('13','Mattos','Alexander Teixeira','1865','1921','mx'), ('14','Anderson','Frederick Irving','1877','1947','us'), ('15','Christie','Agatha','1892','1976','uk'), ('16','Garvice','Charles','1853','1920','us'), ('17','Ewer','Mary Cartwright','1797','1877','us'), ('18','Warren','John Russell','1886','1958','us'), ('19','Bell','John Joy','1871','1934','us'), ('20','Deeping','Warwick','1877','1950','uk'), ('21','Rowlands','Effie Adelaide','1866','1936','us'), ('22','Nayler','Benjamin Suggit','1796','1878','uk'), ('23','M�ller','Frederik','1817','1881','nl'), ('24','Sijthoff','Albertus Willem','1829','1913','nl'), ('25','Frentzen','Carl Georg','1846','1914','de'), ('26','Fuhri','Koenraad','1814','1858','nl'), ('27','Kamp, Van der','Walter','1926','2003','nl'), ('28','Deinum','Hans','1903','1982','nl'), ('30','P�tillon-Mulder','Willy','1883','1948','nl') ; 
  " ; 
  
  executeSQL( $query ) ; 
  
  
  function executeSQL($sql) 
  {
  
  
  print "<p>Query: <b>$sql</b></p>" ; 
  
  $host="localhost" ; 
  $user="bdms" ; 
  $password="bdms" ;
  $name_db = "booktrade_tutorial" ; 
  
  $db = mysql_connect($host, $user, $password ) ;
  if ($db)
  {
  
  mysql_select_db($name_db) or die( "Unable to select database");
  
  
  if ( mysql_db_query($name_db,$sql,$db ) )
  {
  
  print "Query successful! <br/>" ; 
  
  }
  else 
  {
  print "Query could not be executed : <br/>" ; 
  print mysql_errno() . ": " . mysql_error();
  }
  
  
  
  }
  else
  {
  print ("Connection could not be established.") ;
  }
  
  mysql_close($db);
  
  }
  
  
  
  ?>
  </p>
  </body>
  </html>	 
  
  