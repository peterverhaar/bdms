
<?php
$file = $_GET[file] ; 
?>


<h3>SQL Keywords</h3>

<table>


  <tr>
  <td width="5%">
  <?php
  if($file == "sql1.html")
  {
  print "<img src=\"arrow.gif\">" ; 
  }
  else
  {
  print "<img src=\"bullet.gif\">" ;
  } 
  ?>
  
  </td><td>
  <a href="index.php?file=sql1.html">Introduction</a><br/>
  </td></tr>




    <tr>
<td width="5%">
<?php
if($file == "sql2.html")
{
print "<img src=\"arrow.gif\">" ; 
}
else
{
print "<img src=\"bullet.gif\">" ;
} 
?>

</td><td>
<a href="index.php?file=sql2.html">FROM, SELECT, WHERE, DISTINCT</a><br/>
</td></tr>
    <tr><td width="5%">
<?php
if($file == "sql3.html")
{
print "<img src=\"arrow.gif\">" ; 
}
else
{
print "<img src=\"bullet.gif\">" ;
} 
?>
    </td><td><a href="index.php?file=sql3.html">ORDER BY</a></td></tr>
    <tr><td width="5%">
<?php
if($file == "sql4.html")
{
print "<img src=\"arrow.gif\">" ; 
}
else
{
print "<img src=\"bullet.gif\">" ;
} 
?>
        </td><td>
        <a href="index.php?file=sql4.html" >AGGREGATE FUNCTIONS</a>
            </td></tr>
    <tr><td width="5%">
     <?php
if($file == "sql5.html")
{
print "<img src=\"arrow.gif\">" ; 
}
else
{
print "<img src=\"bullet.gif\">" ;
} 
?>       </td><td>
<a href="index.php?file=sql5.html" >GROUP BY</a>
         </td></tr>
    <tr><td width="5%">
     <?php
if($file == "sql6.html")
{
print "<img src=\"arrow.gif\">" ; 
}
else
{
print "<img src=\"bullet.gif\">" ;
} 
?>       </td><td>
<a href="index.php?file=sql6.html" >HAVING</a>
         </td></tr>
    <tr><td width="5%">
     <?php
if($file == "sql7.html")
{
print "<img src=\"arrow.gif\">" ; 
}
else
{
print "<img src=\"bullet.gif\">" ;
} 
?>       </td><td>
<a href="index.php?file=sql7.html" >INNER JOIN</a>   </td></tr>


    <tr><td width="5%">
     <?php
if($file == "sql8.html")
{
print "<img src=\"arrow.gif\">" ; 
}
else
{
print "<img src=\"bullet.gif\">" ;
} 
?>       </td><td>
<a href="index.php?file=sql8.html" >LEFT JOIN</a>   </td></tr>


    </table>
    
    
    
    
    

<h3>Examples</h3>

<table>


  <tr>
  <td width="5%">
  <?php
  if($file == "sql9.html")
  {
  print "<img src=\"arrow.gif\">" ; 
  }
  else
  {
  print "<img src=\"bullet.gif\">" ;
  } 
  ?>
  
  </td><td>
  <a href="index.php?file=sql9.html">A structured approach to writing queries</a><br/>
  </td></tr>




    <tr>
<td width="5%">
<?php
if($file == "sql10.html")
{
print "<img src=\"arrow.gif\">" ; 
}
else
{
print "<img src=\"bullet.gif\">" ;
} 
?>

</td><td>
<a href="index.php?file=sql10.html">Example 1</a><br/>
</td></tr>
    <tr><td width="5%">
<?php
if($file == "sql11.html")
{
print "<img src=\"arrow.gif\">" ; 
}
else
{
print "<img src=\"bullet.gif\">" ;
} 
?>
    </td><td><a href="index.php?file=sql11.html">Example 2</a></td></tr>
    <tr><td width="5%">
<?php
if($file == "sql12.html")
{
print "<img src=\"arrow.gif\">" ; 
}
else
{
print "<img src=\"bullet.gif\">" ;
} 
?>
        </td><td>
        <a href="index.php?file=sql12.html" >Example 3</a>
            </td></tr>
            
             <tr><td width="5%">
<?php
if($file == "sql13.html")
{
print "<img src=\"arrow.gif\">" ; 
}
else
{
print "<img src=\"bullet.gif\">" ;
} 
?>
        </td><td>
        <a href="index.php?file=sql13.html" >Example 4</a>
            </td></tr>
            
             <tr><td width="5%">
<?php
if($file == "sql14.html")
{
print "<img src=\"arrow.gif\">" ; 
}
else
{
print "<img src=\"bullet.gif\">" ;
} 
?>
        </td><td>
        <a href="index.php?file=sql14.html" >Example 5</a>
            </td></tr>
            
             <tr><td width="5%">
<?php
if($file == "sql15.html")
{
print "<img src=\"arrow.gif\">" ; 
}
else
{
print "<img src=\"bullet.gif\">" ;
} 
?>
        </td><td>
        <a href="index.php?file=sql15.html" >Example 6</a>
            </td></tr>
            
            </table>
    
    

