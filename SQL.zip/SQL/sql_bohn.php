<html>
<head><title>Execute SQL statement</title>


</head>
<body>
  <tr> 
    <td colspan="2" height="67"> 

    </td>
  </tr>
<body>

<?php

 $sql= $_POST['sql'] ; 
 
 $sql = trim( $sql ) ; 


    $sql = str_replace("\\" , "", $sql);



if(!eregi("^SELECT", $sql))
{
    die( "<b>The query needs to begin with select! </b>" ) ; 
}





executeSQL($sql) ; 

   
function executeSQL($sql) 
  {
    
    
    print "<p>Query: <b>$sql</b></p>" ; 
    
  $host="localhost" ; 
  $user="bdms" ; 
  $password="booktrade" ;
 $name_db = "bohnBooks" ; 
 
 $db = mysql_connect($host, $user, $password ) ;
 if ($db)
 {
 
 mysql_select_db($name_db) or die( "Unable to select database");
 
 
if ( $result = mysql_db_query($name_db,$sql,$db ) )
 {


print "<table border=\"1\" cellpadding=\"10\">" ; 

while ($row = mysql_fetch_array ($result) )
{

$count = count($row) ; 

print " <tr>";

for($c = 0 ; $c < $count ; $c++)
{
if(isset($row[$c] ))
    {
print ("<td> $row[$c] </td> ") ;
}

}
    
    print "</tr>" ; 
    
}

print "</table>" ; 


    
    }
 else 
 {
 print "Query could not be executed : <br/>" ; 
 print mysql_errno() . ": " . mysql_error();
 }
 
 
 
 }
 else
 {
 print ("Connection could not be established.") ;
 }
 
 }
 

?>
</p>
</body>
</html>	 

