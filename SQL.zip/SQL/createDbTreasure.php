<html>
<head><title>Create database TREASURE</title></head>
<body>
  <tr> 
  <td colspan="2" height="67"> 
  <h2>TREASURE database</h2>
  </td>
  </tr>
  <body>
  
  
  
  <p>
  
  <?php
  
  
  $con = mysql_connect("localhost","bdms","bdms");
  
  
  if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
  
  if (mysql_query("DROP DATABASE treasure ; ",$con))
  {
  echo "<p>Database deleted! </p>";
  }
  else
  {
  echo "Error deleting database: " . mysql_error();
  }
  
  if (mysql_query("CREATE DATABASE treasure ; ",$con))
  {
  echo "<p>Database created!</p> ";
  }
  else
  {
  echo "Error creating database: " . mysql_error();
  }
  
  mysql_close($con);
  
  $query = "
  CREATE TABLE CREATOR
  ( 
  CREATOR_ID INT NOT NULL AUTO_INCREMENT,
  NAME_LAST VARCHAR(60) NOT NULL,
  NAME_FIRST VARCHAR(40) NOT NULL,
  YEAR_OF_BIRTH INT(4),
  YEAR_OF_DEATH INT(4),
  COUNTRY_BORN CHAR(2),
  PRIMARY KEY (CREATOR_ID),
  FOREIGN KEY (COUNTRY_BORN) REFERENCES COUNTRY ON DELETE RESTRICT ON UPDATE CASCADE
  );
  " ; 
  
  executeSQL( $query ) ; 
  
  
  
  $query = "
  CREATE TABLE COUNTRY
  ( 
  COUNTRY_CODE CHAR(2) NOT NULL,
  NAME VARCHAR (40),
  PRIMARY KEY (COUNTRY_CODE)
  ) ; 
  
  " ; 
  
  executeSQL( $query ) ; 
  
  
  $query = "
  CREATE TABLE CITY
  ( 
  CITY_CODE CHAR(6) NOT NULL,
  NAME VARCHAR (40),
  COUNTRY CHAR (3),
  PRIMARY KEY (CITY_CODE),
  FOREIGN KEY (COUNTRY) REFERENCES COUNTRY ON DELETE RESTRICT ON UPDATE CASCADE
  ); 
  
  " ; 
  
  executeSQL( $query ) ; 
  
  
  
  $query = "
  CREATE TABLE LIBRARY
  ( 
  LIBRARY_ID CHAR(6) NOT NULL,
  NAME VARCHAR (50),  
  CITY CHAR (6),
  PRIMARY KEY (LIBRARY_ID),
  FOREIGN KEY (CITY) REFERENCES CITY ON DELETE RESTRICT ON UPDATE CASCADE
  ); 
  
  " ; 
  
  executeSQL( $query ) ; 
  
  $query = "
  CREATE TABLE SUBJECT
  ( 
  CODE CHAR(3) NOT NULL,
  SUBJECT VARCHAR (40),
  PRIMARY KEY (CODE)
  ); 
  
  " ; 
  
  executeSQL( $query ) ; 
  

  
  $query = "
  CREATE TABLE TREASURE
  ( 
  TREASURE_ID INT (4) NOT NULL AUTO_INCREMENT,
  TITLE VARCHAR (150),
  CREATOR INT,
  LIBRARY CHAR(6), 
  SUBJECT CHAR(3), 
  YEAR INT (4),  
  PRIMARY KEY (TREASURE_ID),
  FOREIGN KEY (CREATOR) REFERENCES CREATOR ON DELETE RESTRICT ON UPDATE CASCADE, 
  FOREIGN KEY (LIBRARY) REFERENCES LIBRARY ON DELETE RESTRICT ON UPDATE CASCADE,
  FOREIGN KEY (SUBJECT) REFERENCES SUBJECT ON DELETE RESTRICT ON UPDATE CASCADE
  ); 
  
  " ; 
  
  executeSQL( $query ) ; 
  
  
  $query = "
  INSERT INTO SUBJECT VALUES ('ART','Art and architecture'), ('HIS','History'), ('LIT','Literature'), ('MUS','Music'), ('POL','Politics'), ('SCI','Sciences') ; 
  " ; 
  
  executeSQL( $query ) ; 
  
  $query = "
  INSERT INTO LIBRARY VALUES ('1','�sterreichische Nationalbibliothek','AT VIE'), ('2','Biblioth�que nationale de France','FR PAR'), ('3','Koninklijke Bibliotheek van Belgi�','BE BRU'), ('4','British Library','GB LON'), ('5','Leabharlann Naisuinta na hEireann','IE DUB'), ('6','Biblioteca Nazionale Centrale di Roma','IT ROM'), ('7','Biblioteca Nazionale Centrale di Firenze','IT FLR'), ('9','Deutsche Nationalbibliothek','DE BER') ; 
  " ; 
  executeSQL( $query ) ; 
  
  $query = "
  INSERT INTO COUNTRY VALUES ('AT','Austria'), ('BE','Belgium'), ('DE','Germany'), ('FR','France'), ('GB','United Kingdom'), ('IE','Ireland'), ('IT','Italy'), ('NL','Netherlands') ; 
  " ; 
  
  executeSQL( $query ) ; 
  

  $query = "
  INSERT INTO TREASURE VALUES ('1','Sidereus Nuncius','7','7','SCI','1610'), ('2','Requiem KV 626','2','1','MUS','1791'), ('3','Rabbit Hunt, in the lower left Brueghel 1560.','3','3','ART','1560'), ('4','De antiquitate Britanicae Ecclesiae','8','4','ART','1572'), ('5','Vedute di Roma con scene di costume','6','6','HIS','1810'), ('6','Corrected page proofs of \"Les Fleurs du mal\" ','1','2','HIS','1857'), ('7','Vinegar Hill, charge of the 5th Dragoon Guards','4','5','HIS','1880'), ('8','Poster of \"Internationale Ausstellung f�r Buchgewerbe und Graphik\"','5','9','ART','1914'), ('9','Fontana dei Fiumi a Piazza Navona','9','6','ART','1734') ;  
  " ; 
  
  executeSQL( $query ) ; 
  

  
  $query = "
  INSERT INTO CREATOR VALUES ('1','Baudelaire','Charles','1821','1867','FR'), ('2','Mozart','Wolfgang Amadeus','1756','1791','AT'), ('3','Bruegel The Elder','Pieter','1525','1569','BE'), ('4','Sadler','William','1782','1839','IE'), ('5','Tiemann','Walter','1876','1951','DE'), ('6','Macchiavelli','Giacomo','1756','1811','IT'), ('7','Galilei','Galileo','1564','1642','IT'), ('8','Parker','Matthew','1504','1575','GB'), ('9','Wittel','Caspar van','1655','1736','NL'), ('10','Molyneux','Daniel','1568','1632','IE') ; " ; 
  

  executeSQL( $query ) ; 
  
  $query = "
  INSERT INTO CITY VALUES ('AT VIE','Wien','AT'), ('BE BRU','Brussel','BE'), ('DE BER','Berlin','DE'), ('FR PAR','Paris','FR'), ('GB LON','London','GB'), ('IE DUB','Dublin','IE'), ('IT FLR','Firenze','IT'), ('IT ROM','Roma','IT') ;
  " ; 
  
  executeSQL( $query ) ; 

  
  
  function executeSQL($sql) 
  {
  
  
  print "<p>Query: <b>$sql</b></p>" ; 
  
  $host="localhost" ; 
  $user="bdms" ; 
  $password="bdms" ;
  $name_db = "treasure" ; 
  
  $db = mysql_connect($host, $user, $password ) ;
  if ($db)
  {
  
  mysql_select_db($name_db) or die( "Unable to select database");
  
  
  if ( mysql_db_query($name_db,$sql,$db ) )
  {
  
  print "Query successful! <br/>" ; 
  
  }
  else 
  {
  print "Query could not be executed : <br/>" ; 
  print mysql_errno() . ": " . mysql_error();
  }
  
  
  
  }
  else
  {
  print ("Connection could not be established.") ;
  }
  
  mysql_close($db);
  
  }
  
  
  
  ?>
  </p>
  </body>
  </html>	 
  
  