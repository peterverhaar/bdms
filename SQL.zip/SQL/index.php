<?php


$files = array("sql1.html", "sql2.html", "sql3.html", "sql4.html", "sql5.html", "sql6.html", "sql7.html" , "sql8.html",  "sql9.html",  "sql10.html",  "sql11.html",  "sql12.html",  "sql13.html",  "sql14.html" , "sql15.html") ;
    
if(isset( $_GET["file"]) ) 
{
	$file = $_GET["file"] ;
}
else
{
    $file = "sql1.html" ;
}

if(isset( $_GET["menu"]) ) 
{
	$menu = $_GET["menu"];
}
else
{
    $menu = "yes";
}
     
$count = count($files) ;

for($i = 0 ; $i < $count ; $i++)
{
	if ($files[$i] == $file)
	{
		if($i != 0)
		{
			$prev = $files[$i - 1] ; 
		}
		else
		{
			$prev = $files[$count - 1]; 
		}
		
		if($i != ($count  - 1))
		{
			$next = $files[$i +1]; 
		}
		else
		{
			$next = $files[0]; 
		}
	}
}
     
if(!isset($next))
{
    $next = $files[0] ; 
}

if(!isset($prev))
{
	$prev = $files[($count -1) ];
}

?>
<html>
<head>
<title>SQL course</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="http://bookandbyte.org/style2007.css">
<script language="JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.0
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && document.getElementById) x=document.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>

<body bgcolor="#EBEBEB" text="#000000" leftmargin="0" rightmargin="0" topmargin="0" marginwidth="0" marginheight="0" onLoad="MM_preloadImages('prev.gif','home.gif','next.gif','show.gif','index.gif')">
<table cellpadding="10" cellspacing="0" border="0" width="100%">
  <tr bgcolor="#000033"> 
  <td height="60" width="25%"><img src="sqlcourse.gif" width="170" height="65"></td>
    <td height="60" width="53%">&nbsp;</td>
    <td height="60" width="4%"> 
  
    </td>
    <td height="59" width="4px"> 
      <div align="center"> 
        <p> 
          <?php
        print "<a href=\"index.php?file=".$prev."&menu=".$menu."\" " ;
        ?>
        onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('prev','','prev.gif',1)"><img name="prev" title="Vorige in navigatiemenu" border="0" src="prev2.gif" width="40" height="40"></a><br>
          </p>
      </div>
    </td>
    <td height="59" width="4px"> 
      <div align="center"> 
        <?php
        print "<a href=\"index.php?file=".$next."&menu=".$menu."\" " ;
        ?>
        onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('next','','next.gif',1)"><img name="next" title="Volgende in navigatiemenu" border="0" src="next2.gif" width="40" height="40"></a><br>
        </div>
    </td>
    <td height="59" width="4px"> 
      <div align="center"> 
      <p><a href="index.php?file=sql1.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('home','','home.gif',1)"><img name="home" border="0" src="home2.gif" width="40" height="40" title="home"></a> 
          </p>
      </div>
    </td>
    <td height="59"> 
      <div align="center"> 

      </div>
    </td>
    <td height="60" width="2%">&nbsp;</td>
  </tr>
  <tr> 
    <td height="25" colspan="8">      
    <!-- <div align="right"><img src="../image/printer_icon.gif"/><a href="XSLT.pdf"
    target="_new">Print version</a></div> -->
    </td>
  </tr>
 <tr> 
 <?php
 
if($menu != "no")
{
	print "<td valign=\"top\" width=\"25%\">";
	
	include 'left.php';
	
	print "</td>"; 
}
	?>
    <td bgcolor="#FFFFFF" 
	<?php
	  if($menu != "no")
  {
		print "colspan=\"7\" " ; 
	}
	else
	{
		print "colspan=\"8\" " ; 
	}
	?>
	valign="top" width="14%"> 
	
	<table cellspacing="30" border="0" ><tr><td>
	
      <?php
	
    if(!isset($file))
{
    $file = "sql1.html" ;
}
	
	include $file ;

	    print "<p align=\"right\">[ <a href=\"index.php?file=". $file. "\" >up &nbsp;</a>| <a href=\"index.php?file=". $next. "\"> next </a>] </p>" ; 
	    
	    ?>
	    
	    </td></tr></table>
	    
    </td>
  </tr>
</table>


</body>
</html>
