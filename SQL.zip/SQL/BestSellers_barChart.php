

<?php

$col1 = array() ; 
$col2 = array() ; 

$colName1 ; 
$colName2 ; 

$nRows ; 

$i = 0 ; 


if (isset( $_POST['sql'] ))
{
$sql= $_POST['sql'] ;


 
 $sql = trim( $sql ) ; 

$sql = str_replace("\\" , "", $sql);

if(!eregi("^SELECT", $sql))
{
    die( "<b>The query needs to begin with select! </b>" ) ; 
}
else    
{    
    executeSQL($sql) ; 
} 

}


function executeSQL($sql) 
{
  
  

    $host="localhost" ; 
    $user="bdms" ; 
    $password="booktrade" ;
    $name_db = "bestsellers" ; 
  
    global $col1  ; 
    global $col2 ;
    
    global $colName1 ;
    global $colName2 ;


	global $nRows ;
  
  
  $db = mysql_connect($host, $user, $password ) ;
  if ($db)
  {
  
  mysql_select_db($name_db) or die( "Unable to select database");
  
  
  if ( $result = mysql_db_query($name_db,$sql,$db ) )
  {
  
  $nRows = mysql_num_rows( $result ) ; 
  
  
  $colName1 = mysql_field_name( $result , 0 ) ; 
  $colName2 = mysql_field_name( $result , 1 ) ; 

  
  while ($row = mysql_fetch_array ($result) )
  {
  
       
        $col1[] = $row[0] ; 
        $col2[] = $row[1] ; 
	
  }
  

  
  
  }
  else 
  {
  print "Query could not be executed : <br/>" ; 
  print mysql_errno() . ": " . mysql_error();
  }
  
  
  
  }
  else
  {
  print ("Connection could not be established.") ;
  }
  
  }
  
 

?>






<html>
<head><title>Bar Chart</title>


<style>

.chart {
  font: 10px sans-serif;
  background-color: steelblue;
  text-align: right;
  padding: 3px;
  margin: 1px;
  color: white;
}

body {
   font-family: Arial, sans-serif , Verdana, Georgia, Serif;
}


</style>
		  
		  

</head>
<body>






<table width="100%" border="0"  cellpadding="20">
  <tr style="height: 200px; ">
    <td >
    
    
    
    
    
    	<form action="barChart_sql.php" enctype="multipart/form-data" method="post">
			<input type="hidden" name="MAX_FILE_SIZE" value="100000" />
			<input type="hidden" name="stage" value="process" />
			<textarea cols="40" rows="8" name="sql"></textarea>
			<br/>
			<input type="submit" value="Execute query">
		</form>
    
    
    
    
    
    
    
    </td>
    <td rowspan="2" width="15%;" style=" text-align: center ; ">
    
    <p/>
    
 
    <!-- 
    <table border="1" cellpadding="20">	-->

    
    
    </td>
  </tr>
  <tr style="vertical-align: text-top; ">
    <td>  
    
<?php

if( isset( $sql ) ) {

    print "<p>Query: <b>" . $sql . "</b><br/>" ; 
    
    print "Label: <b>" . $colName1 . "</b><br/>" ; 
    print "Values: <b>" . $colName2  . "</b></p>" ; 
	

}



?>    
    
    
    

	



<table width="100%" cellpadding="5">
	
<?php

for ( $i = 0 ; $i < sizeOf( $col1 ) ; $i++ ) {

	$label = $col1[$i] ; 
	$label = substr( $label, 0 , 20) ;
	
	if( strlen( $col1[$i] ) > 20 ) {
		$label .= " ... " ; 
	}

	print "<tr valign=\"top\"><td width=\"30%\" style=\"text-align: right;\">" . $label . "</td>" ; 
	print "<td><div style=\"width: " . ( $col2[$i] * 5 ) . "px; \" class=\"chart\">" . $col2[$i] .  "</div>" ; 
	print "</td></tr>" ; 
}

?>

</table>  
	

    
    </td>
  </tr>
</table>



	
    

    


</body>
</html>	 

