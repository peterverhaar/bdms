  $host="localhost" ; 
  $user="bdms" ; 
  $password="booktrade" ;
 $name_db = "btcp_sample" ; 